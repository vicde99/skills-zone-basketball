# Skills ZONE Basketball Camp — Website

A premium, single-page marketing website for **Skills ZONE Basketball Camp**, a youth
basketball skills camp in **Alapan Primero, Imus, Cavite, Philippines** (training young
players since 2022).

The site is a **fully self-contained static page** — no build step, no server, no external
dependencies. Every image, font and stylesheet is bundled locally, so it works offline and
hosts anywhere (GitHub Pages, Netlify, Vercel, any static host).

---

## What's in this repository

```
.
├── index.html              # The complete website (single page)
├── 404.html                # Custom "page not found" page (GitHub Pages serves it automatically)
├── favicon.ico             # Multi-size favicon (16/32/48/64) built from the camp logo
├── robots.txt              # Search-engine crawl rules
├── assets/
│   ├── tailwind.css        # Pre-compiled Tailwind CSS (no CDN needed)
│   ├── fonts.css           # @font-face declarations for the self-hosted fonts
│   ├── *.woff2             # Anton, Inter & Instrument Serif font files (14 files)
│   ├── hero.jpg            # Hero background
│   ├── training.jpg        # About section
│   ├── drill.jpg           # Featured program
│   ├── court.jpg           # "Why us" background
│   ├── team.jpg            # Inside-a-session gallery
│   ├── net.jpg             # Inside-a-session gallery
│   ├── equipment.jpg       # Inside-a-session gallery
│   ├── runners.jpg         # Call-to-action background
│   ├── logo.jpg            # Brand mark
│   ├── user-photo-1.jpg    # Camp photo — team huddle (hero, about, gallery, CTA)
│   ├── user-photo-2.jpg    # Camp photo — coaching staff (Coaches section)
│   ├── user-photo-3.jpg    # Camp photo — player progression (gallery)
│   ├── user-photo-4.jpg    # Camp photo — player portrait (featured program, gallery)
│   ├── favicon-16x16.png   # Favicon (16px)
│   ├── favicon-32x32.png   # Favicon (32px)
│   ├── apple-touch-icon.png# iOS home-screen icon (180px)
│   ├── icon-192.png        # PWA / Android icon (192px)
│   └── icon-512.png        # PWA / Android icon (512px)
├── site.json               # Structured site data (business, contact, programs, FAQ…)
├── package.json            # Project metadata + `npm start` local preview script
├── .nojekyll               # Tells GitHub Pages to serve files as-is (no Jekyll processing)
└── README.md               # This file
```

**42 files total.** Every asset the page references lives inside this folder — there are no
CDN links, no Google Fonts and no remote image URLs. The only external requests the page makes
are the camp's own Facebook page link in the footer and the reservation form's POST to
FormSubmit (a form-to-email service) — neither is a build or rendering dependency.

> **Why `.nojekyll`?** GitHub Pages runs Jekyll by default, which ignores files and folders
> that start with an underscore. This site has none, but `.nojekyll` guarantees every file is
> served exactly as committed — a safe default for any static site.

---

## The JSON files

Two JSON files sit at the repo root. Neither is required for the page to render — `index.html`
is fully self-contained — but they make the repo a proper, machine-readable project.

### `site.json` — structured site data

A single source of truth for everything the site says, so the content can be reused by other
tools (a booking form, a directory listing, a mobile app, schema.org markup) without scraping
the HTML. It contains:

- **`business`** — name, tagline, description, type, founded year, audience, tone, logo/favicon paths
- **`contact`** — phone (+ `tel:` link), Facebook page, Messenger link, full postal address
- **`schedule`** — session days, start/end time, duration, arrival note, location
- **`pricing`** — currency, per-session price, payment model, contract terms
- **`programs`** — the five tracks (Weekly Skills Camp, Fundamentals Track, Advance Skills Track,
  Private Coaching, Group Coaching) with level, ages, price and highlights
- **`reservation`** — the reservation email (`info@vextaoneconsulting.com`), the FormSubmit
  endpoint, the Messenger/phone fallback and the form field names
- **`features`** — the four training pillars (Shooting, Ball Handling, Footwork, Fundamentals & IQ)
- **`whyChooseUs`** — the six differentiators
- **`statistics`** — the four animated stat counters (value, prefix, suffix, label)
- **`testimonials`** — the three parent quotes with author, role and rating
- **`faq`** — the six question/answer pairs
- **`navigation`**, **`brand`** (colors + fonts) and **`meta`** (title/description/OG tags)

### `package.json` — project metadata

Standard npm manifest: project name, version, description, keywords, license and a `start`
script for local preview. It declares **no dependencies** — the site needs none.

---

## The other root files

- **`404.html`** — a branded "page not found" page. GitHub Pages serves it automatically for any
  unknown path, so a mistyped URL still lands on the camp's design instead of GitHub's default.
- **`favicon.ico`** + the PNG icons in `assets/` — the camp logo rendered at 16/32/48/64 px
  (`.ico`), 16/32 px (browser tabs), 180 px (iOS home screen) and 192/512 px (Android / PWA).
  All are wired up in `index.html`'s `<head>`.
- **`robots.txt`** — allows search engines to crawl the whole site.

---

## The reservation form

The "Reserve a slot" form on the page collects the parent/guardian name, contact number, email,
player name and age, the selected **program**, a preferred schedule/date and optional notes, then
emails the booking to **`info@vextaoneconsulting.com`**.

It uses **[FormSubmit](https://formsubmit.co)** — a form-to-email service that needs no server of
our own, so it works on GitHub Pages, Hostinger or any static host. The page POSTs the details to
`https://formsubmit.co/ajax/info@vextaoneconsulting.com` and shows a success message on screen.

**Program options in the dropdown:**

1. Weekly Skills Camp
2. Fundamentals Track
3. Advance Skills Track
4. Private Coaching
5. Group Coaching

**One-time activation (important):** the first time the form is submitted, FormSubmit sends a
confirmation email to `info@vextaoneconsulting.com` with an **Activate Form** link. Click that link
once and every future submission is delivered straight to the inbox. Until it is activated,
FormSubmit replies with a message asking for activation.

**Fallback:** if the email send ever fails, the form still shows the **Send via Messenger** button
(which opens a pre-filled chat to the camp's Facebook page) and the click-to-call number, so no
booking is ever lost.

---

## Preview locally

Because everything is bundled, you can just open the file:

```bash
# Option A — open directly
open index.html          # macOS
xdg-open index.html      # Linux
start index.html         # Windows

# Option B — serve it (recommended, mirrors how a host serves it)
python3 -m http.server 8000
# then visit http://localhost:8000

# Option C — via the npm script (uses `serve`, no install needed)
npm start
# then visit http://localhost:8000
```

---

## Deploy to GitHub Pages (free hosting)

### Path 1 — Upload through the GitHub website (no command line)

1. Sign in to [github.com](https://github.com) and click **New repository**.
2. Name it (e.g. `skills-zone-basketball`), set it to **Public**, and click **Create repository**.
3. On the empty repo page, click **uploading an existing file**.
4. Drag in **all the contents of this folder** — `index.html`, `404.html`, `favicon.ico`,
   `robots.txt`, `site.json`, `package.json`, `.nojekyll`, `README.md` and the whole **`assets`**
   folder (keep the `assets/` folder structure intact).
5. Click **Commit changes**.
6. Go to the repo's **Settings → Pages**.
7. Under **Build and deployment → Source**, choose **Deploy from a branch**.
8. Set **Branch** to **`main`** and the folder to **`/ (root)`**, then click **Save**.
9. Wait ~1 minute. Your site goes live at:

   ```
   https://<your-username>.github.io/<your-repo>/
   ```

### Path 2 — Push with Git (command line)

From inside this folder:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

Then enable Pages once: **Settings → Pages → Source: Deploy from a branch → Branch: `main`,
folder `/ (root)` → Save**. Your site will be live at
`https://<your-username>.github.io/<your-repo>/`.

> **Tip:** If you create the repo *with* a README on GitHub first, run
> `git pull --rebase origin main` before pushing, or start from an empty repo as shown above.

---

## Custom domain & HTTPS

- **Custom domain:** In **Settings → Pages → Custom domain**, enter your domain
  (e.g. `skillszonebasketball.com`) and click **Save**. Then, at your domain registrar, add
  the DNS records GitHub shows you:
  - Apex domain (`example.com`) → four `A` records pointing to GitHub's IPs, or an `ALIAS`/`ANAME`.
  - Subdomain (`www.example.com`) → a `CNAME` record pointing to `<your-username>.github.io`.
  - A `CNAME` file is committed to the repo automatically when you save the custom domain.
- **HTTPS is automatic.** Once the domain resolves, tick **Enforce HTTPS** in
  **Settings → Pages** — GitHub provisions a free TLS certificate (may take a few minutes to
  an hour to become available).

---

## Editing the site

- **Text & content:** edit `index.html` directly — it is plain HTML with Tailwind utility classes.
  If you change business details (price, hours, phone), update `site.json` too so the two stay in sync.
- **Colors / fonts:** the design tokens live in the inline `<style>` block at the top of
  `index.html` (CSS variables) and in the compiled `assets/tailwind.css`.
- **Images:** drop a replacement into `assets/` using the same filename and it will be picked up
  automatically.

### Rebuilding the CSS (only if you add new Tailwind classes)

The shipped `assets/tailwind.css` is pre-compiled and covers every class the page uses. If you
add **new** utility classes, regenerate it:

```bash
npm install -D tailwindcss@3
npx tailwindcss -i input.css -o assets/tailwind.css --minify
```

with a `tailwind.config.js` whose `content` points at `./index.html` and whose theme matches the
colors/fonts defined in the page.

---

## License & credits

Website content and design © Skills ZONE Basketball Camp. Fonts: Anton, Inter and Instrument
Serif (Google Fonts, SIL Open Font License). Built as a static, dependency-free page.